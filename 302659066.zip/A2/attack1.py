import hashlib
import time

def generate_hashes_with_time_analysis(file_path):
    hashes = {'MD5': {}, 'SHA1': {}, 'SHA256': {}}
    try:
        # Initialize timers
        md5_time = 0
        sha1_time = 0
        sha256_time = 0

        with open(file_path, 'rb') as file:  # Open in binary mode
            for line in file:
                word = line.strip() 

           
                start_md5 = time.perf_counter()
                md5_hash = hashlib.md5(word).hexdigest()
                md5_time += time.perf_counter() - start_md5

            
                start_sha1 = time.perf_counter()
                sha1_hash = hashlib.sha1(word).hexdigest()
                sha1_time += time.perf_counter() - start_sha1

                # Generate SHA256 hash and measure time
                start_sha256 = time.perf_counter()
                sha256_hash = hashlib.sha256(word).hexdigest()
                sha256_time += time.perf_counter() - start_sha256

                # Store the hashes with the word as the value
                hashes['MD5'][md5_hash] = word.decode('utf-8', errors='ignore')
                hashes['SHA1'][sha1_hash] = word.decode('utf-8', errors='ignore')
                hashes['SHA256'][sha256_hash] = word.decode('utf-8', errors='ignore')

        print("\nTime Analysis:")
        print(f"MD5 Time: {md5_time:.6f} seconds")
        print(f"SHA1 Time: {sha1_time:.6f} seconds")
        print(f"SHA256 Time: {sha256_time:.6f} seconds\n")

    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
    except Exception as e:
        print(f"An error occurred: {e}")
    return hashes

def compare_hashes(hash_files, generated_hashes):
    try:
        for hash_type, file_path in hash_files.items():
            print(f"\nChecking {hash_type} hashes from file: {file_path}\n")
            try:
                with open(file_path, 'r') as file:
                    for line in file:
                        hash_value = line.strip()
                        if hash_value in generated_hashes[hash_type]:
                            word = generated_hashes[hash_type][hash_value]
                            print(f"Match found: Hash: {hash_value}, Word: {word}")
                        else:
                            print(f"No match found for hash: {hash_value}")
            except FileNotFoundError:
                print(f"Error: File '{file_path}' not found.")
    except Exception as e:
        print(f"An error occurred while comparing hashes: {e}")

dictionary_file = 'rockyou.txt'


generated_hashes = generate_hashes_with_time_analysis(dictionary_file)

hash_files = {
    'MD5': 'md5_hashes.txt',
    'SHA1': 'sha1_hashes.txt',
    'SHA256': 'sha256_hashes.txt'
}

# Compare the hashes from the files with the generated hashes
compare_hashes(hash_files, generated_hashes)

