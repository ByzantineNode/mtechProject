import hashlib
import time


def extract_salts_and_hashes(file_path):

    salts = []
    hashes = []  
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
            for line in file:
                line = line.strip()
                if ':' in line:
                    salt, hash_value = line.split(':', 1)
                    salts.append(salt)
                    hashes.append(hash_value)  # Store the hash value
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
    except Exception as e:
        print(f"An error occurred while extracting salts and hashes from '{file_path}': {e}")
    return salts, hashes


def search_and_print_matching_passwords(passwords, salts, target_hashes, hash_function, algorithm_name):

    print(f"\nMatching passwords for {algorithm_name}:")
    
    # Start timing
    start_time = time.perf_counter()
    
    matches_found = 0 

    for salt, target_hash in zip(salts, target_hashes):  # Process salts and hashes in order
        for password in passwords:
      
            combo = password + salt
  
            computed_hash = hash_function(combo.encode()).hexdigest()
       
            if computed_hash == target_hash:
                print(f"Match found: Password: {password}, Salt: {salt}, Hash: {target_hash}")
                matches_found += 1
                break  # Stop further checks for this hash

    # End timing
    end_time = time.perf_counter()
    elapsed_time = end_time - start_time

    print(f"\nTotal matches found for {algorithm_name}: {matches_found}")
    print(f"Total time taken for {algorithm_name}: {elapsed_time:.6f} seconds\n")


if __name__ == "__main__":
    # File paths
    passwords_file = "rockyou.txt"
    md5_file = "md5_salted_hashes.txt"
    sha1_file = "sha1_salted_hashes.txt"
    sha256_file = "sha256_salted_hashes.txt"


    try:
        with open(passwords_file, 'r', encoding='utf-8', errors='ignore') as file:
            passwords = [line.strip() for line in file if line.strip()]
    except FileNotFoundError:
        print(f"Error: Passwords file '{passwords_file}' not found.")
        passwords = []
    except Exception as e:
        print(f"An error occurred while reading '{passwords_file}': {e}")
        passwords = []

    md5_salts, md5_hashes = extract_salts_and_hashes(md5_file)
    sha1_salts, sha1_hashes = extract_salts_and_hashes(sha1_file)
    sha256_salts, sha256_hashes = extract_salts_and_hashes(sha256_file)

 
    if not (md5_salts and md5_hashes and sha1_salts and sha1_hashes and sha256_salts and sha256_hashes):
        print("Error: One or more hash files are missing or empty. Exiting.")
    else:
     
        search_and_print_matching_passwords(
            passwords, md5_salts, md5_hashes, hashlib.md5, "MD5"
        )


        search_and_print_matching_passwords(
            passwords, sha1_salts, sha1_hashes, hashlib.sha1, "SHA1"
        )


        search_and_print_matching_passwords(
            passwords, sha256_salts, sha256_hashes, hashlib.sha256, "SHA256"
        )

