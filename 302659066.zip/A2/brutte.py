import socket
import random

# Configuration
SERVER_IP = "10.208.66.147"  
SERVER_PORT = 5555

ENTRY_NUMBER = "2024JCS2613"

def generate_private_key():
    return random.randint(2, 2**16)

def compute_public_key(g, p, private_key):
    return pow(g, private_key, p)

def compute_shared_secret(public_key, private_key, p):
    return pow(public_key, private_key, p)

def brute_force_private_key(g, p, server_public_key):
    for a in range(1, p): 
        if pow(g, a, p) == server_public_key:
            return a
    return None  

def main():
    try:
      
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
            client_socket.connect((SERVER_IP, SERVER_PORT))
            print("Connected to server")

          
            client_socket.sendall(ENTRY_NUMBER.encode())
            print(f"Sent entry number: {ENTRY_NUMBER}")

            
            response = client_socket.recv(1024).decode()
            p, g = map(int, response.split(","))
            print(f"Received P: {p}, G: {g}")

         
            private_key = generate_private_key()
            public_key = compute_public_key(g, p, private_key)
            print(f"Client's private key: {private_key}")
            print(f"Client's public key: {public_key}")

          
            client_socket.sendall(str(public_key).encode())
            print("Sent client's public key to server")

           
            server_public_key = int(client_socket.recv(1024).decode())
            print(f"Received server's public key: {server_public_key}")

            shared_secret = compute_shared_secret(server_public_key, private_key, p)
            print(f"Shared secret: {shared_secret}")

         
            print("Starting brute-force attack to find server's private key...")
            server_private_key = brute_force_private_key(g, p, server_public_key)
            if server_private_key is not None:
                print(f"Server's private key (found via brute force): {server_private_key}")
            else:
                print("Failed to brute-force the server's private key.")

    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()