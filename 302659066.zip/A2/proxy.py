import socket
import threading

PROXY_IP = "127.0.0.1"  
PROXY_PORT = 1234      

SERVER_IP = "10.237.27.193"  
SERVER_PORT = 5555     

BUFFER_SIZE = 4096      

def modify_client_to_server(data):

    print(f"[Proxy] Client -> Server: {data.decode()}")
    modified_data = input("[Proxy] Enter modified request (or press Enter to keep unchanged): ")
    return modified_data.encode() if modified_data else data

def modify_server_to_client(data):
    
    print(f"[Proxy] Server -> Client: {data.decode()}")
    modified_data = input("[Proxy] Enter modified response (or press Enter to keep unchanged): ")
    return modified_data.encode() if modified_data else data

def handle_client(client_socket, server_ip, server_port):
    
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        # Connect to the real server
        server_socket.connect((server_ip, server_port))
        print("[Proxy] Connected to server")


        while True:
      
            client_data = client_socket.recv(BUFFER_SIZE)
            if not client_data:
                break 
            modified_data = modify_client_to_server(client_data)
            server_socket.sendall(modified_data)

            server_data = server_socket.recv(BUFFER_SIZE)
            if not server_data:
                break  
            modified_data = modify_server_to_client(server_data)
            client_socket.sendall(modified_data)

        print("[Proxy] Connection closed")

def start_proxy(proxy_ip, proxy_port, server_ip, server_port):
    
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as proxy_socket:
        proxy_socket.bind((proxy_ip, proxy_port))
        proxy_socket.listen(5) 
        print(f"[Proxy] Listening on {proxy_ip}:{proxy_port}")

        while True:
            client_socket, client_address = proxy_socket.accept()
            print(f"[Proxy] Accepted connection from {client_address}")

           
            client_thread = threading.Thread(
                target=handle_client, args=(client_socket, server_ip, server_port)
            )
            client_thread.start()

if __name__ == "__main__":
    start_proxy(PROXY_IP, PROXY_PORT, SERVER_IP, SERVER_PORT)