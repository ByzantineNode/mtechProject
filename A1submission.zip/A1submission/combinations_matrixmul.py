#!/usr/bin/env python3
import os
import subprocess


GEM5 = "gem5.opt"
RUN_SCRIPT = "runmatrixmul.py"
BINARY = "./matrixmul"

# Configurations
cpus = ["ATOMIC", "TIMING", "O3"]
freqs = [f"{mhz}MHz" for mhz in range(600, 3400, 400)]  # 600 → 3400 MHz
mems = ["DDR3", "DDR4"]

RESULTS_DIR = "results"

os.makedirs(RESULTS_DIR, exist_ok=True)

for cpu in cpus:
    for clk in freqs:
        for mem in mems:
            outdir = f"{RESULTS_DIR}/{cpu}_{clk}_{mem}"
            os.makedirs(outdir, exist_ok=True)

            cmd = [
                GEM5,
                "-d", outdir,
                RUN_SCRIPT,
                "--binary", BINARY,
                "--cpu", cpu,
                "--clk", clk,
                "--mem", mem,
            ]

            print(f"\n>>> Running: {' '.join(cmd)}")
            subprocess.run(cmd, check=True)