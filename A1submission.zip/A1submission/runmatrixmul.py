from gem5.components.boards.simple_board import SimpleBoard
from gem5.components.cachehierarchies.classic.no_cache import NoCache
from gem5.components.memory.single_channel import *
from gem5.components.processors.simple_processor import SimpleProcessor
from gem5.components.processors.cpu_types import CPUTypes
from gem5.resources.resource import CustomResource
from gem5.simulate.simulator import Simulator
from gem5.isas import ISA
import argparse

# Global CPU map
CPU_MAP = {
    "ATOMIC": CPUTypes.ATOMIC,
    "TIMING": CPUTypes.TIMING,
    "O3": CPUTypes.O3,
}

def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", type=str, default="./mm",
                        help="Path to matrix-multiply binary")
    parser.add_argument("--cpu", type=str, default="TIMING",
                        help="CPU type: ATOMIC | TIMING | O3")
    parser.add_argument("--clk", type=str, default="1GHz",
                        help="Clock frequency")
    parser.add_argument("--mem", type=str, default="DDR3",
                        help="Memory type: DDR3 | DDR4")
    return parser.parse_args()

def build_processor(cpu_type: str):
    return SimpleProcessor(
        cpu_type=CPU_MAP[cpu_type],
        num_cores=1,
        isa=ISA.X86
    )

def build_memory(mem_type: str):
    if mem_type == "DDR3":
        return SingleChannelDDR3_1600("1GiB")
    elif mem_type == "DDR4":
        from gem5.components.memory.single_channel import SingleChannelDDR4_2400
        return SingleChannelDDR4_2400("1GiB")
    else:
        raise ValueError("Unsupported memory type")

def build_board(clk: str, processor, memory):
    return SimpleBoard(
        clk_freq=clk,
        processor=processor,
        memory=memory,
        cache_hierarchy=NoCache(),
    )

def run_simulation(binary_path: str, cpu: str, clk: str, mem: str):
    processor = build_processor(cpu)
    memory = build_memory(mem)
    board = build_board(clk, processor, memory)

    binary = CustomResource(binary_path)
    board.set_se_binary_workload(binary)

    simulator = Simulator(board=board)
    simulator.run()

def main():
    args = parse_arguments()
    run_simulation(args.binary, args.cpu, args.clk, args.mem)

if __name__ == "__main__":
    main()
