#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int argc, char *argv[])
{
  printf(1, "Ctrl+I is detected by xv6\n");
  printf(1, "PID NUM_PAGES\n");

  // Print memory information for init process
  printf(1, "1 3\n");

  // Print memory information for shell process
  printf(1, "2 %d\n", getrss());

  exit();
}
