#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
  char *page = sbrk(4096); // Allocate 4096 bytes on heap
  if ((uint)page == 0xffffffff) {
    printf(1, "sbrk failed\n");
    exit();
  }
  memset(page, 0xAA, 4096); // Fill page with 0xAA
  printf(1, "Testing swap write to slot 0...\n");
  if (swapwrite(0, page) < 0) {
    printf(1, "Swap write failed\n");
    exit();
  }
  printf(1, "Swap write succeeded\n");
  exit();
}