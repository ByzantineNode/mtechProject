#include "types.h"
#include "stat.h"
#include "user.h"

#define PGSIZE 4096
#define N 100  // Allocate enough pages to force swapping

int
main(void)
{
  printf(1, "Simple swap test starting\n");
  
  // Allocate a large amount of memory to force swapping
  char *mem = malloc(N * PGSIZE);
  if(mem == 0) {
    printf(1, "simpletest: malloc failed\n");
    exit();
  }
  
  printf(1, "simpletest: allocated %d pages at 0x%x\n", N, mem);
  
  // Write a pattern to memory
  for(int i = 0; i < N; i++) {
    mem[i * PGSIZE] = (char)(i & 0xff);
    printf(1, "simpletest: written page %d\n", i);
  }
  
  // Verify the pattern
  for(int i = 0; i < N; i++) {
    if(mem[i * PGSIZE] != (char)(i & 0xff)) {
      printf(1, "simpletest: data mismatch at page %d\n", i);
      exit();
    }
    printf(1, "simpletest: verified page %d\n", i);
  }
  
  printf(1, "Simple swap test passed!\n");
  free(mem);
  exit();
}
