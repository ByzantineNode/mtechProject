#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "defs.h"
#include "x86.h"
#include "pageswap.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "buf.h"

// Adaptive page replacement parameters
#ifndef ALPHA
#define ALPHA 25  // Default alpha value (percentage)
#endif

#ifndef BETA
#define BETA 10   // Default beta value (percentage)
#endif

#define THRESHOLD_INIT 100  // Initial threshold
#define NPAGES_INIT 4       // Initial number of pages to swap
#define LIMIT 100           // Maximum number of pages to swap

// Global variables for adaptive swapping
int threshold = THRESHOLD_INIT;
int npages = NPAGES_INIT;

extern struct {
  struct spinlock lock;
  struct proc proc[NPROC];
} ptable;

struct swap_slot swap_slots[NSWAPSLOTS];
struct spinlock swap_lock;

// Global timestamp counter for page access tracking
uint global_timestamp = 0;

void
init_swap_slots(void)
{
  initlock(&swap_lock, "swap");

  // Reset global timestamp
  global_timestamp = 0;

  // Initialize all swap slots to be free
  for(int i = 0; i < NSWAPSLOTS; i++) {
    swap_slots[i].is_free = 1;
    swap_slots[i].page_perm = 0;
    swap_slots[i].pid = 0;
  }

  // Reset all process swapped pages arrays
  struct proc *p;
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++) {
    for(int i = 0; i < MAX_SWAPPED_PAGES; i++) {
      p->swapped[i].valid = 0;
    }
  }

  // cprintf("Initialized %d swap slots\n", NSWAPSLOTS);
}

void
check_swap_slots(void)
{
  int free_count = 0;
  for(int i = 0; i < NSWAPSLOTS; i++) {
    if(swap_slots[i].is_free == 1 && swap_slots[i].page_perm == 0)
      free_count++;
  }
  // cprintf("Initialized %d free swap slots\n", free_count);
}


void print_swap_slots(void) {
  cprintf("Swap slots: %d %d\n", swap_slots[0].is_free, swap_slots[0].page_perm);
}


// Read a page from a swap slot
int
read_from_swap(uint blockno, char *buf)
{
  struct buf *b;
  int i;

  // Read 8 blocks (4096 bytes) from disk
  for(i = 0; i < 8; i++) {
    b = bread(0, SWAPSTART + blockno + i);  // Device 0 is the swap device
    memmove(buf + i * 512, b->data, 512);
    brelse(b);
  }

  return 0;
}

// Write a page to a swap slot
void
write_swap_page(uint blockno, char *page)
{
  struct buf *b;
  int i;

  // Write 8 blocks (4096 bytes) to disk
  for(i = 0; i < 8; i++) {
    b = bread(0, SWAPSTART + blockno + i);  // Device 0 is the swap device
    memmove(b->data, page + i * 512, 512);
    bwrite(b);
    brelse(b);
  }
}

// Find the process with the highest RSS
struct proc*
find_highest_rss_proc(void)
{
  struct proc *p;
  struct proc *highest = 0;
  int max_rss = 0;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++) {
    if(p->state == RUNNABLE || p->state == RUNNING || p->state == SLEEPING) {
      if(p->rss > max_rss || (p->rss == max_rss && highest && p->pid < highest->pid)) {
        max_rss = p->rss;
        highest = p;
      }
    }
  }

  return highest;
}

// Swap out a page from a process
int
swap_out(struct proc *p)
{
  pte_t *pte;
  uint va;
  int i, j;
  char *mem;

  if(p == 0)
    return -1;

  // Find a free swap slot
  acquire(&swap_lock);
  for(i = 0; i < NSWAPSLOTS; i++) {
    if(swap_slots[i].is_free) {
      swap_slots[i].is_free = 0;
      swap_slots[i].pid = p->pid;
      break;
    }
  }
  release(&swap_lock);

  if(i == NSWAPSLOTS) {
    cprintf("swap_out: no free swap slots\n");
    return -1;
  }

  // Find a free slot in the process's swapped pages array
  for(j = 0; j < MAX_SWAPPED_PAGES; j++) {
    if(!p->swapped[j].valid)
      break;
  }

  if(j == MAX_SWAPPED_PAGES) {
    cprintf("swap_out: no free slots in process's swapped pages array\n");
    acquire(&swap_lock);
    swap_slots[i].is_free = 1;
    swap_slots[i].pid = 0;
    release(&swap_lock);
    return -1;
  }

  // Find a page to swap out with PTE_P flag set and PTE_A flag unset
  for(va = 0; va < p->sz; va += PGSIZE) {
    pte = walkpgdir(p->pgdir, (char*)va, 0);
    if(pte && (*pte & PTE_P) && (*pte & PTE_U) && !(*pte & PTE_A)) {
      // Found a user page that's present and not recently accessed (PTE_A not set)
      uint pa = PTE_ADDR(*pte);
      mem = P2V(pa);

      // Save the page permissions
      swap_slots[i].page_perm = *pte & 0xFFF;

      // Write the page to the swap slot
      write_swap_page(i * 8, mem);

      // Update the page table entry to mark the page as swapped out
      *pte = (*pte & ~PTE_P) | PTE_PG | (i << 12);

      // Update the process's swapped pages array
      p->swapped[j].va = va;
      p->swapped[j].slotno = i;
      p->swapped[j].valid = 1;
      p->swapped[j].timestamp = global_timestamp;

      // Free the physical memory
      kfree(mem);

      // Update RSS
      p->rss--;

      // Invalidate the TLB entry for this page
      lcr3(V2P(p->pgdir));

      return 0;
    }
  }

  // If no pages with PTE_A unset are found, clear PTE_A for all pages and try again
  for(va = 0; va < p->sz; va += PGSIZE) {
    pte = walkpgdir(p->pgdir, (char*)va, 0);
    if(pte && (*pte & PTE_P) && (*pte & PTE_U)) {
      // Clear the PTE_A flag for all pages
      *pte &= ~PTE_A;
    }
  }

  // Try again with PTE_A cleared
  for(va = 0; va < p->sz; va += PGSIZE) {
    pte = walkpgdir(p->pgdir, (char*)va, 0);
    if(pte && (*pte & PTE_P) && (*pte & PTE_U)) {
      // Found a user page that's present
      uint pa = PTE_ADDR(*pte);
      mem = P2V(pa);

      // Save the page permissions
      swap_slots[i].page_perm = *pte & 0xFFF;

      // Write the page to the swap slot
      write_swap_page(i * 8, mem);

      // Update the page table entry to mark the page as swapped out
      *pte = (*pte & ~PTE_P) | PTE_PG | (i << 12);

      // Update the process's swapped pages array
      p->swapped[j].va = va;
      p->swapped[j].slotno = i;
      p->swapped[j].valid = 1;
      p->swapped[j].timestamp = global_timestamp;

      // Free the physical memory
      kfree(mem);

      // Update RSS
      p->rss--;

      // Invalidate the TLB entry for this page
      lcr3(V2P(p->pgdir));

      return 0;
    }
  }

  cprintf("swap_out: no pages to swap out\n");
  acquire(&swap_lock);
  swap_slots[i].is_free = 1;
  swap_slots[i].pid = 0;
  release(&swap_lock);
  return -1;
}

// Swap in a page to a process
int __attribute__((used))
swap_in(struct proc *p, uint va)
{
  pte_t *pte;
  int i;
  char *mem;

  if(p == 0)
    return -1;

  // Find the page in the process's swapped pages array
  for(i = 0; i < MAX_SWAPPED_PAGES; i++) {
    if(p->swapped[i].valid && p->swapped[i].va == PGROUNDDOWN(va))
      break;
  }

  if(i == MAX_SWAPPED_PAGES) {
    cprintf("swap_in: page not found in swapped pages array\n");
    return -1;
  }

  // Allocate physical memory for the page
  mem = kalloc();
  if(mem == 0) {
    // Try to swap out another page to free up memory
    struct proc *highest_rss_proc = find_highest_rss_proc();
    if(highest_rss_proc && swap_out(highest_rss_proc) == 0) {
      // Try to allocate memory again
      mem = kalloc();
      if(mem == 0) {
        cprintf("swap_in: out of memory\n");
        return -1;
      }
    } else {
      cprintf("swap_in: out of memory\n");
      return -1;
    }
  }

  // Read the page from the swap slot
  if(read_from_swap(p->swapped[i].slotno * 8, mem) < 0) {
    kfree(mem);
    return -1;
  }

  // Update the page table entry
  pte = walkpgdir(p->pgdir, (char*)p->swapped[i].va, 0);
  if(pte == 0) {
    kfree(mem);
    return -1;
  }

  // Mark the page as present and accessed
  *pte = V2P(mem) | PTE_P | PTE_A | (swap_slots[p->swapped[i].slotno].page_perm & ~PTE_PG);

  // Free the swap slot
  acquire(&swap_lock);
  swap_slots[p->swapped[i].slotno].is_free = 1;
  swap_slots[p->swapped[i].slotno].pid = 0;
  release(&swap_lock);

  // Mark the swapped page as invalid
  p->swapped[i].valid = 0;

  // Update RSS
  p->rss++;

  // Invalidate the TLB entry for this page
  lcr3(V2P(p->pgdir));

  return 0;
}

void __attribute__((used))
test_swap_write(void)
{
  char page[4096];
  memset(page, 0xAA, 4096); // Fill with 0xAA
  write_swap_page(0, page); // Write to swap partition start
  cprintf("Wrote test page to swap blocks\n");
}

// Check if we need to perform adaptive swapping
int
check_adaptive_swap(void)
{
  int free_pages = getfreepages();

  if(free_pages < threshold) {
    cprintf("Current Threshold = %d, Swapping %d pages\n", threshold, npages);
    return 1;
  }

  return 0;
}

// Perform adaptive swapping
void
do_adaptive_swap(void)
{
  int i;
  struct proc *p;

  // Swap out npages pages
  for(i = 0; i < npages; i++) {
    p = find_highest_rss_proc();
    if(p) {
      swap_out(p);
    } else {
      break;  // No more processes to swap from
    }
  }

  // Update threshold and npages
  threshold = (threshold * (100 - BETA)) / 100;  // Take floor value
  npages = (npages * (100 + ALPHA)) / 100;       // Take floor value

  // Ensure npages doesn't exceed LIMIT
  if(npages > LIMIT) {
    npages = LIMIT;
  }
}

// Reset adaptive swapping parameters
void
reset_adaptive_swap(void)
{
  threshold = THRESHOLD_INIT;
  npages = NPAGES_INIT;
}

