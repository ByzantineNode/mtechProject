#include "types.h"
#include "stat.h"
#include "user.h"

#define PGSIZE 4096
#define N 600  // Allocate enough pages to force swapping

int
main(void)
{
  printf(1, "Swap test starting\n");
  
  // Allocate a large amount of memory to force swapping
  char *mem = malloc(N * PGSIZE);
  if(mem == 0) {
    printf(1, "swaptest: malloc failed\n");
    exit();
  }
  
  printf(1, "swaptest: allocated %d pages at 0x%x\n", N, mem);
  
  // Write a pattern to memory
  for(int i = 0; i < N; i++) {
    for(int j = 0; j < PGSIZE; j++) {
      mem[i * PGSIZE + j] = (char)((i + j) & 0xff);
    }
    if(i % 100 == 0)
      printf(1, "swaptest: written %d pages\n", i);
  }
  
  printf(1, "swaptest: finished writing\n");
  
  // Verify the pattern
  for(int i = 0; i < N; i++) {
    for(int j = 0; j < PGSIZE; j++) {
      if(mem[i * PGSIZE + j] != (char)((i + j) & 0xff)) {
        printf(1, "swaptest: data mismatch at page %d offset %d\n", i, j);
        exit();
      }
    }
    if(i % 100 == 0)
      printf(1, "swaptest: verified %d pages\n", i);
  }
  
  printf(1, "swaptest: all data verified correctly\n");
  
  // Test fork with swapped pages
  int pid = fork();
  if(pid < 0) {
    printf(1, "swaptest: fork failed\n");
    exit();
  }
  
  if(pid == 0) {
    // Child process
    printf(1, "swaptest: child verifying data\n");
    
    // Verify the pattern in the child
    for(int i = 0; i < N; i++) {
      for(int j = 0; j < PGSIZE; j++) {
        if(mem[i * PGSIZE + j] != (char)((i + j) & 0xff)) {
          printf(1, "swaptest child: data mismatch at page %d offset %d\n", i, j);
          exit();
        }
      }
      if(i % 100 == 0)
        printf(1, "swaptest child: verified %d pages\n", i);
    }
    
    printf(1, "swaptest: child verified all data correctly\n");
    exit();
  } else {
    // Parent process
    wait();
    printf(1, "swaptest: child completed\n");
  }
  
  free(mem);
  printf(1, "Swap test passed!\n");
  exit();
}
