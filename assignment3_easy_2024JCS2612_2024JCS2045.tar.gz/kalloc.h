#ifndef _KALLOC_H_
#define _KALLOC_H_

#include "types.h"
#include "spinlock.h"

struct kmem {
  struct spinlock lock;
  struct run *freelist;
};

extern struct kmem kmem;

#endif // _KALLOC_H_ 