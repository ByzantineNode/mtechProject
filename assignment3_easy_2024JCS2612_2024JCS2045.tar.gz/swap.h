#ifndef _SWAP_H_
#define _SWAP_H_

#include "types.h"

#define NSWAPSLOTS 800  // Number of swap slots
#define PAGESIZE 4096   // Page size in bytes
#define SWAPBLOCKS_PER_PAGE (PAGESIZE / BSIZE)  // Number of blocks per page (8 blocks)

// Swap slot structure
struct swap_slot {
    int page_perm;  // Permission of swapped memory page
    int is_free;    // Availability of swap slot
};

// Swap area starts after superblock
#define SWAPSTART 2  // After boot block (0) and superblock (1)
#define SWAPSIZE (NSWAPSLOTS * SWAPBLOCKS_PER_PAGE)  // Total number of swap blocks

#endif // _SWAP_H_ 