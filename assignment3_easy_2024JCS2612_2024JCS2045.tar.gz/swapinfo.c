#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
  printf(1, "Swap info test starting\n");
  
  // Get the current RSS value
  int rss = getrss();
  printf(1, "Current RSS: %d pages\n", rss);
  
  // Allocate some memory to see if it affects RSS
  char *mem = malloc(10 * 4096);  // 10 pages
  if(mem == 0) {
    printf(1, "swapinfo: malloc failed\n");
    exit();
  }
  
  // Write to the memory to ensure it's allocated
  for(int i = 0; i < 10; i++) {
    mem[i * 4096] = (char)(i & 0xff);
  }
  
  // Get the new RSS value
  int new_rss = getrss();
  printf(1, "New RSS after allocating 10 pages: %d pages\n", new_rss);
  printf(1, "Difference: %d pages\n", new_rss - rss);
  
  // Free the memory
  free(mem);
  
  // Get the final RSS value
  int final_rss = getrss();
  printf(1, "Final RSS after freeing memory: %d pages\n", final_rss);
  
  printf(1, "Swap info test completed\n");
  exit();
}
