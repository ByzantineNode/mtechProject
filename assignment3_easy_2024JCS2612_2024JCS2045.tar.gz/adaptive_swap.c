#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"
#include "spinlock.h"

// Adaptive page replacement parameters
#ifndef ALPHA
#define ALPHA 25  // Default alpha value (percentage)
#endif

#ifndef BETA
#define BETA 10   // Default beta value (percentage)
#endif

#define THRESHOLD_INIT 100  // Initial threshold
#define NPAGES_INIT 2       // Initial number of pages to swap
#define LIMIT 100           // Maximum number of pages to swap

// Global variables for adaptive swapping
int threshold = THRESHOLD_INIT;
int npages = NPAGES_INIT;

// Check if we need to perform adaptive swapping
int
check_adaptive_swap(void)
{
  int free_pages = getfreepages();

  if(free_pages < threshold) {
    cprintf("Current Threshold = %d, Swapping %d pages\n", threshold, npages);
    return 1;
  }

  return 0;
}

// Perform adaptive swapping
void
do_adaptive_swap(void)
{
  int i;
  struct proc *p;

  // Swap out npages pages
  for(i = 0; i < npages; i++) {
    p = find_highest_rss_proc();
    if(p) {
      swap_out(p);
    } else {
      break;  // No more processes to swap from
    }
  }

  // Update threshold and npages
  threshold = (threshold * (100 - BETA)) / 100;  // Take floor value
  npages = (npages * (100 + ALPHA)) / 100;       // Take floor value

  // Ensure npages doesn't exceed LIMIT
  if(npages > LIMIT) {
    npages = LIMIT;
  }
}

// Reset adaptive swapping parameters
void
reset_adaptive_swap(void)
{
  threshold = THRESHOLD_INIT;
  npages = NPAGES_INIT;
}
