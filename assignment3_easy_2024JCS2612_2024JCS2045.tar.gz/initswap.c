#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
  printf(1, "Initializing swap slots\n");
  
  // Call a system call to initialize swap slots
  if(initswap() < 0) {
    printf(1, "initswap: failed to initialize swap slots\n");
    exit();
  }
  
  printf(1, "Swap slots initialized\n");
  exit();
}
