#ifndef PAGESWAP_H
#define PAGESWAP_H

#define NSWAPSLOTS 800
#define PAGE_AGE_THRESHOLD 10  // Threshold for page age to avoid thrashing

// Global timestamp counter for page access tracking
extern uint global_timestamp;

// Forward declaration
struct proc;

// Structure to track a swap slot
struct swap_slot {
  int page_perm; // Permissions of the swapped page
  int is_free;   // 1 if free, 0 if occupied
  int pid;       // PID of the process that owns this slot
};

extern struct swap_slot swap_slots[NSWAPSLOTS];

// Initialize swap slots
void init_swap_slots(void);

// Write a page to a swap slot
void write_swap_page(uint blockno, char *page);

// Read a page from a swap slot
int read_from_swap(uint blockno, char *buf);

// Swap out a page from a process
int swap_out(struct proc *p);

// Swap in a page to a process
int swap_in(struct proc *p, uint va);

// Find the process with the highest RSS
struct proc* find_highest_rss_proc(void);

// Adaptive swapping functions
int check_adaptive_swap(void);
void do_adaptive_swap(void);
void reset_adaptive_swap(void);


// Test functions
void test_swap_write(void);
void print_swap_slots(void);
void check_swap_slots(void);
void print_superblock(void);

#endif