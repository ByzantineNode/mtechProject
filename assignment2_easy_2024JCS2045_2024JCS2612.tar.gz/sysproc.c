#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"
extern int signalWrapper();
extern int sigreturnWrapper();
#ifndef SIGFG
#define SIGFG 11 // Example value—adjust as needed.
#endif

// Wrapper function to resume foreground processes and suspend the shell.
void update_foreground_and_shell_state(struct proctable *ptable)
{
  struct proc *p;
  acquire(&ptable->lock);

  for (p = ptable->proc; p < &ptable->proc[NPROC]; p++)
  {
    if (p && (p->pid > 2) && p->suspended == 1)
    {
      p->suspended = 0;
      p->state = RUNNABLE;
    }
    else if (p && p->pid == 2)
    {
      p->state = SLEEPING;
    }
  }

  release(&ptable->lock);
}

int resume_foreground_and_suspend_shell(struct proctable *ptable)
{
  cprintf("Ctrl-F is detected by xv6\n");
  update_foreground_and_shell_state(ptable);
  return SIGFG;
}

int sys_fork(void)
{
  return fork();
}

int sys_exit(void)
{
  exit();
  return 0; // not reached
}

int sys_wait(void)
{
  return wait();
}

int sys_kill(void)
{
  int pid;

  if (argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int sys_getpid(void)
{
  return myproc()->pid;
}

int sys_sbrk(void)
{
  int addr;
  int n;

  if (argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if (growproc(n) < 0)
    return -1;
  return addr;
}

int sys_sleep(void)
{
  int n;
  uint ticks0;

  if (argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while (ticks - ticks0 < n)
  {
    if (myproc()->killed)
    {
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
//=================CTRL+G========================
int sys_signal(void)
{
  // sighandler_t handler;
  // if (argptr(0, (void *)&handler, sizeof(handler)) < 0)
  //   return -1;
  // struct proc *p = myproc();
  // p->signal_handler = handler;
  // // No stub is passed; we rely on a magic value for returning.
  // return 0;
  return signalWrapper(); // defined at proc.c
}

// sys_sigreturn: (You may keep this simple.) Here, we restore the saved trapframe
int sys_sigreturn(void)
{
  // struct proc *p = myproc();
  // if (p->saved_tf == 0)
  //   return -1; // Nothing saved.
  // memmove(p->tf, p->saved_tf, sizeof(struct trapframe));
  // kfree((char *)p->saved_tf);
  // p->saved_tf = 0;
  // return 0;
  return sigreturnWrapper(); // defined at console.c
}
//=================CTRL+G========================

// This function is called when Ctrl+C is pressed.
void ctrlCcode(struct proctable *ptable)
{
  struct proc *p;
  acquire(&ptable->lock);
  p = ptable->proc;
  while (p < &ptable->proc[NPROC])
  {
    if (p->pid > 2)
    {
      p->killed = 1;
    }
    p++;
  }
  release(&ptable->lock);
}
//=================Assign2 Scheduler========================
int sys_custom_fork(void)
{
  int start_later, exec_time;
  if (argint(0, &start_later) < 0 || argint(1, &exec_time) < 0)
    return -1;
  return custom_fork(start_later, exec_time);
}

int sys_scheduler_start(void)
{
  scheduler_start();
  return 0;
}