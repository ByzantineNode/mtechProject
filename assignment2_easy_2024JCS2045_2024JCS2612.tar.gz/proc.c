#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "proc.h"
#include "spinlock.h"
//==============================Scheduler==========================================
#define INT_MIN (-2147483648) // 32-bit signed int minimum
#define INT_MAX 2147483647    // 32-bit signed int maximum

// #define INIT_PRIORITY 100
//  #define ALPHA 2 // Increased CPU penalty
//  #define BETA 1  // Decreased wait bonus
#define PRIORITY_BOOST_THRESHOLD 100
// ctrl+B+F===================
extern void ctrlCcode(struct proctable *);
// Ctrl+G===================
extern void sigcustomWrapper(void);
// shifted the proctable to proc.h
struct proctable ptable; // Process table

static struct proc *initproc;

int nextpid = 1;
extern void forkret(void);
extern void trapret(void);

static void wakeup1(void *chan);

void pinit(void)
{
  initlock(&ptable.lock, "ptable");
}
//=========================CTRL+G========================
void send_sigcustom(void)
{
  sigcustomWrapper(); // defined at syscall.c
}
//=========================CTRL+G========================

// Must be called with interrupts disabled
int cpuid()
{
  return mycpu() - cpus;
}

// Must be called with interrupts disabled to avoid the caller being
// rescheduled between reading lapicid and running through the loop.
struct cpu *
mycpu(void)
{
  int apicid, i;

  if (readeflags() & FL_IF)
    panic("mycpu called with interrupts enabled\n");

  apicid = lapicid();
  // APIC IDs are not guaranteed to be contiguous. Maybe we should have
  // a reverse map, or reserve a register to store &cpus[i].
  for (i = 0; i < ncpu; ++i)
  {
    if (cpus[i].apicid == apicid)
      return &cpus[i];
  }
  panic("unknown apicid\n");
}
//////////////////----------------------------//////////////////////////////////////
// adding funtion for CTRL+C
//  New function to broadcast SIGINT (Ctrl+C)
void ctrlCwrapper(void)
{
  ctrlCcode(&ptable); // passed this call to sysproc.c
}

//////////////////----------------------------////////////////////////////////////////
// Disable interrupts so that we are not rescheduled
// while reading proc from the cpu structure
struct proc *
myproc(void)
{
  struct cpu *c;
  struct proc *p;
  pushcli();
  c = mycpu();
  p = c->proc;
  popcli();
  return p;
}

// PAGEBREAK: 32
//  Look in the process table for an UNUSED proc.
//  If found, change state to EMBRYO and initialize
//  state required to run in the kernel.
//  Otherwise return 0.
static struct proc *
allocproc(void)
{
  struct proc *p;
  char *sp;

  acquire(&ptable.lock);

  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    if (p->state == UNUSED)
      goto found;

  release(&ptable.lock);
  return 0;

found:
  p->state = EMBRYO;
  p->pid = nextpid++;
  p->initial_priority = INIT_PRIORITY;
  p->priority = p->initial_priority;
  p->cpu_ticks = 0;
  p->wait_ticks = 0;

  release(&ptable.lock);

  // Allocate kernel stack.
  if ((p->kstack = kalloc()) == 0)
  {
    p->state = UNUSED;
    return 0;
  }
  sp = p->kstack + KSTACKSIZE;

  // Leave room for trap frame.
  sp -= sizeof *p->tf;
  p->tf = (struct trapframe *)sp;

  // Set up new context to start executing at forkret,
  // which returns to trapret.
  sp -= 4;
  *(uint *)sp = (uint)trapret;

  sp -= sizeof *p->context;
  p->context = (struct context *)sp;
  memset(p->context, 0, sizeof *p->context);
  p->context->eip = (uint)forkret;

  return p;
}

void userinit(void)
{
  struct proc *p;
  extern char _binary_initcode_start[], _binary_initcode_size[];

  p = allocproc();

  initproc = p;
  if ((p->pgdir = setupkvm()) == 0)
    panic("userinit: out of memory?");
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
  p->sz = PGSIZE;
  memset(p->tf, 0, sizeof(*p->tf));
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
  p->tf->es = p->tf->ds;
  p->tf->ss = p->tf->ds;
  p->tf->eflags = FL_IF;
  p->tf->esp = PGSIZE;
  p->tf->eip = 0; // beginning of initcode.S

  safestrcpy(p->name, "initcode", sizeof(p->name));
  p->cwd = namei("/");

  // this assignment to p->state lets other cores
  // run this process. the acquire forces the above
  // writes to be visible, and the lock is also needed
  // because the assignment might not be atomic.
  acquire(&ptable.lock);

  p->state = RUNNABLE;

  release(&ptable.lock);
}

// Grow current process's memory by n bytes.
// Return 0 on success, -1 on failure.
int growproc(int n)
{
  uint sz;
  struct proc *curproc = myproc();

  sz = curproc->sz;
  if (n > 0)
  {
    if ((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
      return -1;
  }
  else if (n < 0)
  {
    if ((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
      return -1;
  }
  curproc->sz = sz;
  switchuvm(curproc);
  return 0;
}

int fork(void)
{
  int i, pid;
  struct proc *np;
  struct proc *curproc = myproc();

  if ((np = allocproc()) == 0)
  {
    return -1;
  }

  if ((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0)
  {
    kfree(np->kstack);
    np->kstack = 0;
    np->state = UNUSED;
    return -1;
  }
  np->sz = curproc->sz;
  np->parent = curproc;
  *np->tf = *curproc->tf;
  np->tf->eax = 0;

  for (i = 0; i < NOFILE; i++)
    if (curproc->ofile[i])
      np->ofile[i] = filedup(curproc->ofile[i]);
  np->cwd = idup(curproc->cwd);

  safestrcpy(np->name, curproc->name, sizeof(curproc->name));

  np->start_later = 0;
  np->exec_time = 0;
  np->cpu_ticks = 0;
  np->wait_ticks = 0;
  np->start_ticks = ticks; // Use global ticks from trap.c
  np->first_run_ticks = -1;
  np->end_ticks = 0;
  np->context_switches = 0;

  // cprintf("Process %d created at tick %d\n", np->pid, ticks);

  pid = np->pid;

  acquire(&ptable.lock);
  np->state = RUNNABLE;
  // ctrl+B+F=============================================
  np->suspended = 0; // Set background process flag to 0
  // cprintf("Process %d set to RUNNABLE at tick %d\n", pid, ticks);
  release(&ptable.lock);

  return pid;
}

// Add this function to proc.c
int custom_fork(int start_later, int exec_time)
{
  int i, pid;
  struct proc *np;
  struct proc *curproc = myproc();

  if ((np = allocproc()) == 0)
  {
    return -1;
  }

  if ((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0)
  {
    kfree(np->kstack);
    np->kstack = 0;
    np->state = UNUSED;
    return -1;
  }
  np->sz = curproc->sz;
  np->parent = curproc;
  *np->tf = *curproc->tf;
  np->tf->eax = 0;

  for (i = 0; i < NOFILE; i++)
    if (curproc->ofile[i])
      np->ofile[i] = filedup(curproc->ofile[i]);
  np->cwd = idup(curproc->cwd);

  safestrcpy(np->name, curproc->name, sizeof(curproc->name));

  np->start_later = start_later;
  np->exec_time = exec_time;
  np->cpu_ticks = 0;
  np->wait_ticks = 0;
  np->start_ticks = ticks; // Use global ticks from trap.c
  np->first_run_ticks = -1;
  np->end_ticks = 0;
  np->context_switches = 0;

  // cprintf("Process %d created at tick %d\n", np->pid, ticks);

  pid = np->pid;

  acquire(&ptable.lock);
  if (start_later)
    np->state = EMBRYO;
  else
    np->state = RUNNABLE;
  // cprintf("Process %d set to state %d at tick %d\n", np->pid, np->state, ticks);
  release(&ptable.lock);

  return pid;
}
// Exit the current process.  Does not return.
// An exited process remains in the zombie state
// until its parent calls wait() to find out it exited.
void exit(void)
{
  struct proc *curproc = myproc();
  struct proc *p;
  int fd;

  if (curproc == initproc)
    panic("init exiting");

  // Close all open files.
  for (fd = 0; fd < NOFILE; fd++)
  {
    if (curproc->ofile[fd])
    {
      fileclose(curproc->ofile[fd]);
      curproc->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(curproc->cwd);
  end_op();
  curproc->cwd = 0;

  acquire(&ptable.lock);
  curproc->end_ticks = ticks; // Set completion time here
  // cprintf("Process %d exiting at tick %d\n", curproc->pid, ticks);

  // Parent might be sleeping in wait().
  wakeup1(curproc->parent);

  // Pass abandoned children to init.
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->parent == curproc)
    {
      p->parent = initproc;
      if (p->state == ZOMBIE)
        wakeup1(initproc);
    }
  }

  // Jump into the scheduler, never to return.
  curproc->state = ZOMBIE;
  sched();
  panic("zombie exit");
}

int wait(void)
{
  struct proc *p;
  int havekids, pid;
  struct proc *curproc = myproc();

  acquire(&ptable.lock);
  for (;;)
  {
    havekids = 0;
    for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    {
      if (p->parent != curproc)
        continue;
      havekids = 1;
      if (p->state == ZOMBIE)
      {
        pid = p->pid;
        if (p->end_ticks == 0) // Only set if not already set
          p->end_ticks = ticks;
        int tat = p->end_ticks - p->start_ticks;
        int wt = p->wait_ticks;
        int rt = (p->first_run_ticks == -1) ? 0 : (p->first_run_ticks - p->start_ticks);
        int cs = p->context_switches;

        cprintf("PID: %d\n", pid);
        cprintf("TAT: %d\n", tat);
        cprintf("WT: %d\n", wt);
        cprintf("RT: %d\n", rt);
        cprintf("#CS: %d\n", cs);

        kfree(p->kstack);
        p->kstack = 0;
        freevm(p->pgdir);
        p->pid = 0;
        p->parent = 0;
        p->name[0] = 0;
        p->killed = 0;
        p->state = UNUSED;
        release(&ptable.lock);
        return pid;
      }
      //=======================Ctrl+B+F=========================================
      if (p && p->suspended == 1 && curproc->pid == 2)
      {
        release(&ptable.lock);
        return pid;
      }
    }
    if (!havekids || curproc->killed)
    {
      release(&ptable.lock);
      return -1;
    }
    sleep(curproc, &ptable.lock);
  }
}
// PAGEBREAK: 42
//  Per-CPU process scheduler.
//  Each CPU calls scheduler() after setting itself up.
//  Scheduler never returns.  It loops, doing:
//   - choose a process to run
//   - swtch to start running that process
//   - eventually that process transfers control
//       via swtch back to the scheduler.
void scheduler_start(void)
{
  struct proc *p;
  acquire(&ptable.lock);
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->state == EMBRYO && p->start_later)
    {
      p->state = RUNNABLE;
      p->priority = p->initial_priority; // Reset priority
      p->wait_ticks = 0;                 // Reset wait time
      p->cpu_ticks = 0;                  // Reset CPU time
                                         //    cprintf("Process %d transitioned from EMBRYO to RUNNABLE\n", p->pid);
    }
  }
  release(&ptable.lock);
}

// static struct proc *last_scheduled = 0;

void scheduler(void)
{
  struct proc *p;
  struct cpu *c = mycpu();
  struct proc *prev_proc = c->proc; // Keep track of previous process
  c->proc = 0;

  for (;;)
  {
    sti();
    acquire(&ptable.lock);

    struct proc *selected = 0;
    int highest_priority = INT_MIN;
    int runnable_count = 0;

    // First pass: Calculate priorities and find highest
    for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    {
      if (p->suspended == 1)
        continue;
      if (p->state == RUNNABLE)
      {
        runnable_count++;

        // Priority boosting for long-waiting processes
        if (p->wait_ticks > PRIORITY_BOOST_THRESHOLD)
        {
          p->priority = p->initial_priority;
          p->wait_ticks = 0;
          p->cpu_ticks = 0;
        }
        else
        {
          // Calculate priority according to the formula: πi(t) = πi(0) − α · Ci(t) + β · Wi(t)
          int new_priority = p->initial_priority - ALPHA * p->cpu_ticks + BETA * p->wait_ticks;

          // Prevent priority from going below 0
          if (new_priority < 0)
            new_priority = 0;
          if (new_priority > INT_MAX)
            new_priority = INT_MAX;

          p->priority = new_priority;
        }

        // Select process with highest priority
        if (p->priority > highest_priority)
        {
          highest_priority = p->priority;
          selected = p;
        }
        else if (p->priority == highest_priority && selected && p->pid < selected->pid)
        {
          selected = p; // Break ties using lowest PID
        }
      }
    }

    if (selected)
    {
      // Update wait times for all other RUNNABLE processes
      for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
      {
        if (p->state == RUNNABLE && p != selected)
        {
          p->wait_ticks++;
        }
      }

      // Switch to chosen process
      c->proc = selected;
      switchuvm(selected);
      selected->state = RUNNING;
      selected->cpu_ticks++;

      // Increment context switches if switching to a different process
      if (prev_proc != selected)
      {
        selected->context_switches++;
      }

      if (selected->first_run_ticks == -1)
      {
        selected->first_run_ticks = ticks;
      }

      swtch(&(c->scheduler), selected->context);
      switchkvm();

      // Process is done running for now
      if (selected->exec_time > 0 && selected->cpu_ticks >= selected->exec_time)
      {
        selected->killed = 1;
        if (selected->state == RUNNING)
        {
          selected->end_ticks = ticks;
          selected->state = ZOMBIE;
          // Ensure process exits
          if (selected->parent)
            wakeup1(selected->parent);
        }
      }

      prev_proc = selected; // Update previous process
      c->proc = 0;
    }
    release(&ptable.lock);
  }
}

void sched(void)
{
  int intena;
  struct proc *p = myproc();

  if (!holding(&ptable.lock))
    panic("sched ptable.lock");
  if (mycpu()->ncli != 1)
    panic("sched locks");
  if (p->state == RUNNING)
    panic("sched running");
  if (readeflags() & FL_IF)
    panic("sched interruptible");
  intena = mycpu()->intena;
  swtch(&p->context, mycpu()->scheduler);
  mycpu()->intena = intena;
}

// Give up the CPU for one scheduling round.
void yield(void)
{
  acquire(&ptable.lock); // DOC: yieldlock
  myproc()->state = RUNNABLE;
  sched();
  release(&ptable.lock);
}

// A fork child's very first scheduling by scheduler()
// will swtch here.  "Return" to user space.
void forkret(void)
{
  static int first = 1;
  // Still holding ptable.lock from scheduler.
  release(&ptable.lock);

  if (first)
  {
    // Some initialization functions must be run in the context
    // of a regular process (e.g., they call sleep), and thus cannot
    // be run from main().
    first = 0;
    iinit(ROOTDEV);
    initlog(ROOTDEV);
  }

  // Return to "caller", actually trapret (see allocproc).
}

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void sleep(void *chan, struct spinlock *lk)
{
  struct proc *p = myproc();

  if (p == 0)
    panic("sleep");

  if (lk == 0)
    panic("sleep without lk");

  // Must acquire ptable.lock in order to
  // change p->state and then call sched.
  // Once we hold ptable.lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup runs with ptable.lock locked),
  // so it's okay to release lk.
  if (lk != &ptable.lock)
  {                        // DOC: sleeplock0
    acquire(&ptable.lock); // DOC: sleeplock1
    release(lk);
  }
  // Go to sleep.
  p->chan = chan;
  p->state = SLEEPING;

  sched();

  // Tidy up.
  p->chan = 0;

  // Reacquire original lock.
  if (lk != &ptable.lock)
  { // DOC: sleeplock2
    release(&ptable.lock);
    acquire(lk);
  }
}

// PAGEBREAK!
//  Wake up all processes sleeping on chan.
//  The ptable lock must be held.
static void
wakeup1(void *chan)
{
  struct proc *p;

  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    if (p->state == SLEEPING && p->chan == chan)
      p->state = RUNNABLE;
}

// Wake up all processes sleeping on chan.
void wakeup(void *chan)
{
  acquire(&ptable.lock);
  wakeup1(chan);
  release(&ptable.lock);
}

// Kill the process with the given pid.
// Process won't exit until it returns
// to user space (see trap in trap.c).
int kill(int pid)
{
  struct proc *p;

  acquire(&ptable.lock);
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->pid == pid)
    {
      p->killed = 1;
      // Wake process from sleep if necessary.
      if (p->state == SLEEPING)
        p->state = RUNNABLE;
      release(&ptable.lock);
      return 0;
    }
  }
  release(&ptable.lock);
  return -1;
}

// PAGEBREAK: 36
//  Print a process listing to console.  For debugging.
//  Runs when user types ^P on console.
//  No lock to avoid wedging a stuck machine further.
void procdump(void)
{
  static char *states[] = {
      [UNUSED] "unused",
      [EMBRYO] "embryo",
      [SLEEPING] "sleep ",
      [RUNNABLE] "runble",
      [RUNNING] "run   ",
      [ZOMBIE] "zombie"};
  int i;
  struct proc *p;
  char *state;
  uint pc[10];

  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    cprintf("%d %s %s", p->pid, state, p->name);
    if (p->state == SLEEPING)
    {
      getcallerpcs((uint *)p->context->ebp + 2, pc);
      for (i = 0; i < 10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
  }
}

//===================CTRL+G========================
int signalWrapper()
{
  sighandler_t handler;
  if (argptr(0, (void *)&handler, sizeof(handler)) < 0)
    return -1;
  struct proc *p = myproc();
  p->signal_handler = handler;
  // No stub is passed; we rely on a magic value for returning.
  return 0;
}