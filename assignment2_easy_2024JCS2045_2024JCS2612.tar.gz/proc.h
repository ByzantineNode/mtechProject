#ifndef PROC_H
#define PROC_H
#include "spinlock.h"
// #include "memlayout.h"
//  Per-CPU state
//  ctrl+B+F
#define SIGBG 2 // Ctrl+B signal
#define SIGFG 3 // Ctrl+F signal

#define FLAG_CTRLB 0x01 // bit 0 for Ctrl+B
#define FLAG_CTRLF 0x02 // bit 1 for Ctrl+F

struct cpu
{
  uchar apicid;              // Local APIC ID
  struct context *scheduler; // swtch() here to enter scheduler
  struct taskstate ts;       // Used by x86 to find stack for interrupt
  struct segdesc gdt[NSEGS]; // x86 global descriptor table
  volatile uint started;     // Has the CPU started?
  int ncli;                  // Depth of pushcli nesting.
  int intena;                // Were interrupts enabled before pushcli?
  struct proc *proc;         // The process running on this cpu or null
};

extern struct cpu cpus[NCPU];
extern int ncpu;

// PAGEBREAK: 17
//  Saved registers for kernel context switches.
//  Don't need to save all the segment registers (%cs, etc),
//  because they are constant across kernel contexts.
//  Don't need to save %eax, %ecx, %edx, because the
//  x86 convention is that the caller has saved them.
//  Contexts are stored at the bottom of the stack they
//  describe; the stack pointer is the address of the context.
//  The layout of the context matches the layout of the stack in swtch.S
//  at the "Switch stacks" comment. Switch doesn't save eip explicitly,
//  but it is on the stack and allocproc() manipulates it.
struct context
{
  uint edi;
  uint esi;
  uint ebx;
  uint ebp;
  uint eip;
};

enum procstate
{
  UNUSED,
  EMBRYO,
  SLEEPING,
  RUNNABLE,
  RUNNING,
  ZOMBIE
};
//=================CTRL+G========================
typedef void (*sighandler_t)(void);
//=================CTRL+G========================
// Per-process state
struct proc
{
  uint sz;                    // Size of process memory (bytes)
  pde_t *pgdir;               // Page table
  char *kstack;               // Bottom of kernel stack for this process
  enum procstate state;       // Process state
  int pid;                    // Process ID
  struct proc *parent;        // Parent process
  struct trapframe *tf;       // Trap frame for current syscall
  struct context *context;    // swtch() here to run process
  void *chan;                 // If non-zero, sleeping on chan
  int killed;                 // If non-zero, have been killed
  struct file *ofile[NOFILE]; // Open files
  struct inode *cwd;          // Current directory
  char name[16];              // Process name (debugging)
  //=================CTRL+G========================
  int pending_signal;          // 1 if SIGCUSTOM is pending; else 0.
  sighandler_t signal_handler; // User-registered signal handler.
  struct trapframe *saved_tf;  // A copy of the trapframe saved when signal was delivered.
  //=================CTRL+G========================
  ///======ctrl+B+F====
  // change this to suspended
  int suspended; // Background process flag
  // new fields for Assignment 2 scheduler
  int start_later; // Flag to indicate if process should start later
  int exec_time;   // Execution time limit in ticks
  int cpu_ticks;   // Total CPU ticks consumed
  int wait_ticks;  // Total waiting time in ticks
  int start_ticks; // Time when process was created        // Process name (debugging)

  int first_run_ticks;  // Time of first run for response time
  int end_ticks;        // Time when process completes
  int context_switches; // Number of context switches

  int priority;         // Dynamic priority
  int initial_priority; // πi(0)
};

// Process memory is laid out contiguously, low addresses first:
//   text
//   original data and bss
//   fixed-size stack
//   expandable heap
struct proctable
{
  struct spinlock lock;    // For mutual exclusion
  struct proc proc[NPROC]; // Process table
};
#endif // PROC_H
