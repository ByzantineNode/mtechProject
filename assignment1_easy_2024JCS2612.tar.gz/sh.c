#include "types.h"
#include "user.h"
#include "fcntl.h"
#include "history_struct.h"

/* Maximum arguments and command types */
#define MAXARGS 10
#define EXEC 1
#define REDIR 2
#define PIPE 3
#define LIST 4
#define BACK 5
// extern int login();

int get_input(char *prompt, char *buffer, int size)
{
  printf(1, "%s", prompt);
  gets(buffer, size);

  int len = strlen(buffer);
  if (len > 0 && buffer[len - 1] == '\n')
    buffer[len - 1] = '\0'; // Remove newline character

  return len > 0; // Return success if input is not empty
}

int validate_credentials(const char *username, const char *password)
{
  if (strcmp(username, USERNAME) != 0)
  {
    printf(1, "Invalid username\n");
    return 0;
  }

  if (strcmp(password, PASSWORD) != 0)
  {
    printf(1, "Incorrect password\n");
    return 0;
  }

  return 1; // Valid credentials
}

int login()
{
  char username[32];
  char password[32];
  int attempts = 0;

  while (attempts < 3)
  {
    if (!get_input("Enter username: ", username, sizeof(username)))
      continue;

    if (!get_input("Enter password: ", password, sizeof(password)))
      continue;

    if (validate_credentials(username, password))
    {
      printf(1, "Login successful!\n");
      return 0; // Success
    }

    attempts++;
  }

  return -1; // Failed login
}
/* Command structure definitions */
struct cmd
{
  int type;
};

struct execcmd
{
  int type;
  char *argv[MAXARGS];
  char *eargv[MAXARGS];
};

struct redircmd
{
  int type;
  struct cmd *cmd;
  char *file;
  char *efile;
  int mode;
  int fd;
};

/* Optional block command structure */
struct blockcmd
{
  int type;
  int syscall_id;
};

struct pipecmd
{
  int type;
  struct cmd *left;
  struct cmd *right;
};

struct listcmd
{
  int type;
  struct cmd *left;
  struct cmd *right;
};

struct backcmd
{
  int type;
  struct cmd *cmd;
};

/* Function prototypes */
int fork1(void);
void panic(char *);
struct cmd *parsecmd(char *);
int block(int);
int unblock(int);
int gethistory(char *);
int setshellpid(int);
int chdir(const char *);
int exec(char *, char **);

/* Parsing function prototypes */
struct cmd *parseline(char **, char *);
struct cmd *parsepipe(char **, char *);
struct cmd *parseexec(char **, char *);
struct cmd *nulterminate(struct cmd *);

int login_wrapper()
{
  return login(); // Calls the actual login function in syscall.c
}

/*---------------------------------------------------------------------
 * runcmd: Executes a parsed command. Never returns.
 *
 * Note: The recursion here is intentional since commands may be nested.
 * Each branch terminates via exit() when the command has been handled.
 */
void runcmd(struct cmd *cmd)
{
  if (cmd == 0)
    exit(); // Base case to prevent infinite recursion

  switch (cmd->type)
  {
  case EXEC:
  {
    struct execcmd *ecmd = (struct execcmd *)cmd;
    if (ecmd->argv[0] == 0)
      exit();
    exec(ecmd->argv[0], ecmd->argv);
    printf(2, "exec %s failed\n", ecmd->argv[0]);
    exit();
  }
  case REDIR:
  {
    struct redircmd *rcmd = (struct redircmd *)cmd;
    close(rcmd->fd);
    if (open(rcmd->file, rcmd->mode) < 0)
    {
      printf(2, "open %s failed\n", rcmd->file);
      exit();
    }
    runcmd(rcmd->cmd);
    exit();
  }
  case LIST:
  {
    struct listcmd *lcmd = (struct listcmd *)cmd;
    if (fork1() == 0)
      runcmd(lcmd->left);
    wait();
    runcmd(lcmd->right);
    exit();
  }
  case PIPE:
  {
    int p[2];
    struct pipecmd *pcmd = (struct pipecmd *)cmd;
    if (pipe(p) < 0)
      panic("pipe");
    if (fork1() == 0)
    {
      close(1);
      dup(p[1]);
      close(p[0]);
      close(p[1]);
      runcmd(pcmd->left);
    }
    if (fork1() == 0)
    {
      close(0);
      dup(p[0]);
      close(p[0]);
      close(p[1]);
      runcmd(pcmd->right);
    }
    close(p[0]);
    close(p[1]);
    wait();
    wait();
    exit();
  }
  case BACK:
  {
    struct backcmd *bcmd = (struct backcmd *)cmd;
    if (fork1() == 0)
      runcmd(bcmd->cmd);
    exit();
  }
  default:
    panic("runcmd");
  }
}

/*---------------------------------------------------------------------
 * getcmd: Prints a prompt and reads a command into buf.
 */
int getcmd(char *buf, int nbuf)
{
  printf(2, "$ ");
  memset(buf, 0, nbuf);
  gets(buf, nbuf);
  if (buf[0] == 0) // EOF
    return -1;
  return 0;
}

/*---------------------------------------------------------------------
 * main: Logs in, sets the shell PID, opens console, and processes commands.
 */
int main(void)
{
  static char buf[100];
  int fd;
  int attempt = login_wrapper(); // Call login function

  if (attempt >= 3)
  {
    int fd = open("/shutdown", O_CREATE | O_RDWR);
    if (fd >= 0)
      close(fd);
    exit();
  }

  int shell_pid = getpid();
  setshellpid(shell_pid);

  /* Ensure that three file descriptors are open. */
  while ((fd = open("console", O_RDWR)) >= 0)
  {
    if (fd >= 3)
    {
      close(fd);
      break;
    }
  }

  while (getcmd(buf, sizeof(buf)) >= 0)
  {
    if (buf[0] == 0)
      continue;

    /* Create a copy of buf for built-in command checking. */
    char cmdcopy[100];
    strcpy(cmdcopy, buf);
    int len = strlen(cmdcopy);
    if (len > 0 && cmdcopy[len - 1] == '\n')
      cmdcopy[len - 1] = '\0';

    /* Manually extract the first token (command name) from cmdcopy. */
    char *tok = cmdcopy;
    while (*tok == ' ' || *tok == '\t')
      tok++;
    if (*tok == '\0')
      continue;
    char *end = tok;
    while (*end && *end != ' ' && *end != '\t')
      end++;
    char saved = *end;
    *end = '\0';

    /* Check for built-in commands. */
    if (strcmp(tok, "cd") == 0)
    {
      char *arg = end + 1;
      while (*arg == ' ' || *arg == '\t')
        arg++;
      if (*arg == '\0')
      {
        printf(2, "cd: missing argument\n");
      }
      else
      {
        if (chdir(arg) < 0)
          printf(2, "cannot cd %s\n", arg);
      }
      continue;
    }
    if (strcmp(tok, "chmod") == 0)
    {
      char *arg = end + 1;
      while (*arg == ' ' || *arg == '\t')
        arg++;
      if (*arg == '\0')
      {
        printf(2, "Usage: chmod <file> <mode>\n");
      }
      else
      {
        char *file = arg;
        while (*arg != ' ' && *arg != '\t' && *arg != '\0')
          arg++;
        if (*arg == '\0')
        {
          printf(2, "Usage: chmod <file> <mode>\n");
        }
        else
        {
          *arg = '\0'; // Terminate the file string
          arg++;
          while (*arg == ' ' || *arg == '\t')
            arg++;
          if (*arg == '\0')
          {
            printf(2, "Usage: chmod <file> <mode>\n");
          }
          else
          {
            int mode = atoi(arg);
            if (chmod(file, mode) < 0)
            {
              printf(2, "chmod failed\n");
            }
          }
        }
      }
      continue; // avoid forking for this command
    }
    if (strcmp(tok, "block") == 0)
    {
      char *arg = end + 1;
      while (*arg == ' ' || *arg == '\t')
        arg++;
      if (*arg == '\0')
      {
        printf(2, "Usage: block <syscall_id>\n");
      }
      else
      {
        int syscall_id = atoi(arg);
        if (block(syscall_id) == 0)
          printf(1, "Blocked syscall %d\n", syscall_id);
        else
          printf(1, "Failed to block syscall %d\n", syscall_id);
      }
      continue;
    }
    if (strcmp(tok, "unblock") == 0)
    {
      char *arg = end + 1;
      while (*arg == ' ' || *arg == '\t')
        arg++;
      if (*arg == '\0')
      {
        printf(2, "Usage: unblock <syscall_id>\n");
      }
      else
      {
        int syscall_id = atoi(arg);
        if (unblock(syscall_id) == 0)
          printf(1, "Unblocked syscall %d\n", syscall_id);
        else
          printf(1, "Failed to unblock syscall %d\n", syscall_id);
      }
      continue;
    }
    if (strcmp(tok, "history") == 0)
    {
      struct history_struct hist[MAX_LIMIT];
      int count = gethistory((char *)hist);
      if (count < 0)
        printf(2, "Error retrieving history\n");
      else
      {
        for (int i = 0; i < count; i++)
        {
          printf(1, "%d %s %d\n", hist[i].pid, hist[i].name, hist[i].totalMemory);
        }
      }
      continue;
    }

    /* Restore the saved character. */
    *end = saved;

    /* For other commands (e.g., echo, ls, etc.), fork and execute via parsecmd. */
    if (fork1() == 0)
      runcmd(parsecmd(buf));
    wait();
  }
  exit();
}

/*---------------------------------------------------------------------
 * panic: Prints an error message and exits.
 */
void panic(char *s)
{
  printf(2, "%s\n", s);
  exit();
}

/*---------------------------------------------------------------------
 * fork1: A wrapper around fork() that panics on failure.
 */
int fork1(void)
{
  int pid = fork();
  if (pid == -1)
    panic("fork");
  return pid;
}

/*--------------------------
 * Constructors for commands.
 */
struct cmd *execcmd(void)
{
  struct execcmd *cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = EXEC;
  return (struct cmd *)cmd;
}

struct cmd *redircmd(struct cmd *subcmd, char *file, char *efile, int mode, int fd)
{
  struct redircmd *cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = REDIR;
  cmd->cmd = subcmd;
  cmd->file = file;
  cmd->efile = efile;
  cmd->mode = mode;
  cmd->fd = fd;
  return (struct cmd *)cmd;
}

struct cmd *pipecmd(struct cmd *left, struct cmd *right)
{
  struct pipecmd *cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = PIPE;
  cmd->left = left;
  cmd->right = right;
  return (struct cmd *)cmd;
}

struct cmd *listcmd(struct cmd *left, struct cmd *right)
{
  struct listcmd *cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = LIST;
  cmd->left = left;
  cmd->right = right;
  return (struct cmd *)cmd;
}

struct cmd *backcmd(struct cmd *subcmd)
{
  struct backcmd *cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = BACK;
  cmd->cmd = subcmd;
  return (struct cmd *)cmd;
}

/*--------------------------
 * Parsing implementation.
 */
char whitespace[] = " \t\r\n\v";
char symbols[] = "<|>&;()";

int gettoken(char **ps, char *es, char **q, char **eq)
{
  char *s = *ps;
  int ret;
  while (s < es && strchr(whitespace, *s))
    s++;
  if (q)
    *q = s;
  ret = *s;
  switch (*s)
  {
  case 0:
    break;
  case '|':
  case '(':
  case ')':
  case ';':
  case '&':
  case '<':
    s++;
    break;
  case '>':
    s++;
    if (*s == '>')
    {
      ret = '+';
      s++;
    }
    break;
  default:
    ret = 'a';
    while (s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
      s++;
    break;
  }
  if (eq)
    *eq = s;
  while (s < es && strchr(whitespace, *s))
    s++;
  *ps = s;
  return ret;
}

int peek(char **ps, char *es, char *toks)
{
  char *s = *ps;
  while (s < es && strchr(whitespace, *s))
    s++;
  *ps = s;
  return *s && strchr(toks, *s);
}

struct cmd *parseline(char **ps, char *es)
{
  struct cmd *cmd = parsepipe(ps, es);
  while (peek(ps, es, "&"))
  {
    gettoken(ps, es, 0, 0);
    cmd = backcmd(cmd);
  }
  if (peek(ps, es, ";"))
  {
    gettoken(ps, es, 0, 0);
    cmd = listcmd(cmd, parseline(ps, es));
  }
  return cmd;
}

struct cmd *parsepipe(char **ps, char *es)
{
  struct cmd *cmd = parseexec(ps, es);
  if (peek(ps, es, "|"))
  {
    gettoken(ps, es, 0, 0);
    cmd = pipecmd(cmd, parsepipe(ps, es));
  }
  return cmd;
}

struct cmd *parseredirs(struct cmd *cmd, char **ps, char *es)
{
  int tok;
  char *q, *eq;
  while (peek(ps, es, "<>"))
  {
    tok = gettoken(ps, es, 0, 0);
    if (gettoken(ps, es, &q, &eq) != 'a')
      panic("missing file for redirection");
    switch (tok)
    {
    case '<':
      cmd = redircmd(cmd, q, eq, O_RDONLY, 0);
      break;
    case '>':
      cmd = redircmd(cmd, q, eq, O_WRONLY | O_CREATE, 1);
      break;
    case '+': // >>
      cmd = redircmd(cmd, q, eq, O_WRONLY | O_CREATE, 1);
      break;
    }
  }
  return cmd;
}

struct cmd *parseblock(char **ps, char *es)
{
  struct cmd *cmd;
  if (!peek(ps, es, "("))
    panic("parseblock");
  gettoken(ps, es, 0, 0);
  cmd = parseline(ps, es);
  if (!peek(ps, es, ")"))
    panic("syntax - missing )");
  gettoken(ps, es, 0, 0);
  cmd = parseredirs(cmd, ps, es);
  return cmd;
}

struct cmd *parseexec(char **ps, char *es)
{
  char *q, *eq;
  int tok, argc;
  struct execcmd *cmd;
  struct cmd *ret;
  if (peek(ps, es, "("))
    return parseblock(ps, es);
  ret = execcmd();
  cmd = (struct execcmd *)ret;
  argc = 0;
  ret = parseredirs(ret, ps, es);
  while (!peek(ps, es, "|)&;"))
  {
    if ((tok = gettoken(ps, es, &q, &eq)) == 0)
      break;
    if (tok != 'a')
      panic("syntax");
    cmd->argv[argc] = q;
    cmd->eargv[argc] = eq;
    argc++;
    if (argc >= MAXARGS)
      panic("too many args");
    ret = parseredirs(ret, ps, es);
  }
  cmd->argv[argc] = 0;
  cmd->eargv[argc] = 0;
  return ret;
}

struct cmd *nulterminate(struct cmd *cmd)
{
  int i;
  switch (cmd->type)
  {
  case EXEC:
  {
    struct execcmd *ecmd = (struct execcmd *)cmd;
    for (i = 0; ecmd->argv[i]; i++)
      *ecmd->eargv[i] = 0;
    break;
  }
  case REDIR:
  {
    struct redircmd *rcmd = (struct redircmd *)cmd;
    nulterminate(rcmd->cmd);
    *rcmd->efile = 0;
    break;
  }
  case PIPE:
  {
    struct pipecmd *pcmd = (struct pipecmd *)cmd;
    nulterminate(pcmd->left);
    nulterminate(pcmd->right);
    break;
  }
  case LIST:
  {
    struct listcmd *lcmd = (struct listcmd *)cmd;
    nulterminate(lcmd->left);
    nulterminate(lcmd->right);
    break;
  }
  case BACK:
  {
    struct backcmd *bcmd = (struct backcmd *)cmd;
    nulterminate(bcmd->cmd);
    break;
  }
  }
  return cmd;
}

/*
 * Implementation of parsecmd to resolve the undefined reference.
 */
struct cmd *parsecmd(char *s)
{
  char *es;
  struct cmd *cmd;
  es = s + strlen(s);
  cmd = parseline(&s, es);
  if (s != es)
  {
    printf(2, "leftovers: %s\n", s);
    panic("syntax");
  }
  return nulterminate(cmd);
}
