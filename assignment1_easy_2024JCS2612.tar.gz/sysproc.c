#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"
#include "history_struct.h"
#include "syscall.h"
#include "fs.h"
#include "sleeplock.h"
#include "file.h"

extern struct history_struct history_array[MAX_LIMIT]; // Declare the global history array
extern int historyCount;                               // Declare history count
extern struct spinlock history_lock;                   // Declare history lock
extern int wrapper_block(void);                        // Declare the wrapper function for blocking syscalls
extern int wrapper_unblock(void);
extern int wrapper_history(void);
extern int wrapper_sys_chmod(void);
int sys_chmod(void)
{
  return wrapper_sys_chmod();
}

// Block a system call
int sys_block(void)
{
  return wrapper_block();
}

// Unblock a system call
int sys_unblock(void)
{
  return wrapper_unblock();
}

int sys_gethistory(void)
{
  return wrapper_history();
}

int sys_fork(void)
{
  return fork();
}

int sys_exit(void)
{
  exit();
  return 0; // not reached
}

int sys_wait(void)
{
  return wait();
}

int sys_kill(void)
{
  int pid;

  if (argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int sys_getpid(void)
{
  return myproc()->pid;
}

int sys_sbrk(void)
{
  int addr;
  int n;

  if (argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if (growproc(n) < 0)
    return -1;
  return addr;
}

int sys_setshellpid(void)
{
  int shell_pid;
  if (argint(0, &shell_pid) < 0)
    return -1;
  struct proc *curproc = myproc();
  curproc->shell_pid = shell_pid;
}

int sys_sleep(void)
{
  int n;
  uint ticks0;

  if (argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while (ticks - ticks0 < n)
  {
    if (myproc()->killed)
    {
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int deep_wrapper_history()
{
  char *user_buffer;
  int copy_result;

  // Validate user buffer pointer
  if (argptr(0, &user_buffer, sizeof(struct history_struct) * MAX_LIMIT) < 0)
    return -1;

  // Acquire lock and fetch history count
  acquire(&history_lock);
  int count = historyCount;
  release(&history_lock);

  // If no history exists, return immediately
  if (count == 0)
    return 0;

  // Sort history before copying
  sort_history_by_pid();

  // Compute required bytes after sorting
  int bytes = count * sizeof(struct history_struct);

  // Copy history to user space
  copy_result = copyout(myproc()->pgdir, (uint)user_buffer, (char *)history_array, bytes);

  // Return -1 if copy fails, otherwise return count
  return (copy_result < 0) ? -1 : count;
}