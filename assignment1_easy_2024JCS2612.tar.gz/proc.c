#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "proc.h"
#include "fs.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "file.h"
#include "history_struct.h"
// Global history array and supporting variables.
struct history_struct history_array[MAX_LIMIT];
int historyCount = 0;
struct spinlock history_lock;
/* ----------------- End History Tracking Definitions ----------------- */

struct
{
  struct spinlock lock;
  struct proc proc[NPROC];
} ptable;

static struct proc *initproc;
int nextpid = 1;
extern void forkret(void);
extern void trapret(void);
int shell_sid = 1; // Default to 1 (init process)
static void wakeup1(void *chan);

//
// pinit: Initialize the process table and history tracking locks.
//
void pinit(void)
{
  initlock(&ptable.lock, "ptable");
  initlock(&history_lock, "historyLock"); // Initialize our history lock
}

//
// cpuid: Must be called with interrupts disabled.
//
int cpuid()
{
  return mycpu() - cpus;
}

//
// mycpu: Return the current cpu pointer.
//
struct cpu *
mycpu(void)
{
  int apicid, i;

  if (readeflags() & FL_IF)
    panic("mycpu called with interrupts enabled\n");

  apicid = lapicid();
  for (i = 0; i < ncpu; ++i)
  {
    if (cpus[i].apicid == apicid)
      return &cpus[i];
  }
  panic("unknown apicid\n");
}

//
// myproc: Return the current process pointer.
//
struct proc *
myproc(void)
{
  struct cpu *c;
  struct proc *p;
  pushcli();
  c = mycpu();
  p = c->proc;
  popcli();
  return p;
}

//
// allocproc: Allocate a process from the process table.
// Returns a pointer to the allocated process or 0 on failure.
//
static struct proc *
allocproc(void)
{
  struct proc *p;
  char *sp;

  acquire(&ptable.lock);
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->state == UNUSED)
      goto found;
  }
  release(&ptable.lock);
  return 0;

found:
  p->state = EMBRYO;
  p->pid = nextpid++;
  p->magic = 0;
  release(&ptable.lock);

  // Allocate kernel stack.
  if ((p->kstack = kalloc()) == 0)
  {
    p->state = UNUSED;
    return 0;
  }
  sp = p->kstack + KSTACKSIZE;
  // Leave room for trap frame.
  sp -= sizeof *p->tf;
  p->tf = (struct trapframe *)sp;
  // Set up new context to start executing at forkret,
  // which returns to trapret.
  sp -= 4;
  *(uint *)sp = (uint)trapret;
  sp -= sizeof *p->context;
  p->context = (struct context *)sp;
  memset(p->context, 0, sizeof *p->context);
  p->context->eip = (uint)forkret;
  return p;
}

//
// userinit: Set up the first user process.
//
void userinit(void)
{
  struct proc *p;
  extern char _binary_initcode_start[], _binary_initcode_size[];

  p = allocproc();
  initproc = p;
  if ((p->pgdir = setupkvm()) == 0)
    panic("userinit: out of memory?");
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
  p->sz = PGSIZE;
  memset(p->tf, 0, sizeof(*p->tf));
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
  p->tf->es = p->tf->ds;
  p->tf->ss = p->tf->ds;
  p->tf->eflags = FL_IF;
  p->tf->esp = PGSIZE;
  p->tf->eip = 0; // beginning of initcode.S

  safestrcpy(p->name, "initcode", sizeof(p->name));
  p->cwd = namei("/");

  acquire(&ptable.lock);
  p->state = RUNNABLE;
  release(&ptable.lock);
}

//
// growproc: Grow current process's memory by n bytes.
// Return 0 on success, -1 on failure.
//
int growproc(int n)
{
  uint sz;
  struct proc *curproc = myproc();

  sz = curproc->sz;
  if (n > 0)
  {
    if ((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
      return -1;
  }
  else if (n < 0)
  {
    if ((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
      return -1;
  }
  curproc->sz = sz;
  switchuvm(curproc);
  return 0;
}

//
// fork: Create a new process copying the parent's state.
// The new child process is marked RUNNABLE.
//
int fork(void)
{
  int i, pid;
  struct proc *np;
  struct proc *curproc = myproc();

  if ((np = allocproc()) == 0)
  {
    return -1;
  }

  // Copy process state from parent.
  if ((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0)
  {
    kfree(np->kstack);
    np->kstack = 0;
    np->state = UNUSED;
    return -1;
  }
  np->sz = curproc->sz;
  np->parent = curproc;
  *np->tf = *curproc->tf;
  np->tf->eax = 0;

  for (i = 0; i < NOFILE; i++)
  {
    if (curproc->ofile[i])
      np->ofile[i] = filedup(curproc->ofile[i]);
  }
  np->cwd = idup(curproc->cwd);
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
  pid = np->pid;

  // Inherit shell_pid from parent
  np->shell_pid = curproc->shell_pid;

  // Inherit blocked syscalls from parent
  for (i = 0; i < 32; i++)
  {
    np->blocked_syscalls[i] = curproc->blocked_syscalls[i];
  }

  acquire(&ptable.lock);
  np->state = RUNNABLE;
  release(&ptable.lock);

  return pid;
}

void exit(void)
{
  struct proc *curproc = myproc();
  struct proc *p;
  int fd;

  if (curproc == initproc)
    panic("init exiting");

  // Close all open files.
  for (fd = 0; fd < NOFILE; fd++)
  {
    if (curproc->ofile[fd])
    {
      fileclose(curproc->ofile[fd]);
      curproc->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(curproc->cwd);
  end_op();
  curproc->cwd = 0;

  // Acquire the process table lock
  acquire(&ptable.lock);

  // Wake up the parent process.
  wakeup1(curproc->parent);

  // Pass abandoned children to init.
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->parent == curproc)
    {
      p->parent = initproc;
      if (p->state == ZOMBIE)
        wakeup1(initproc);
    }
  }

  // Compute memory usage for this process.
  int memUsage = curproc->sz;

  if (curproc->magic == 1 && historyCount < MAX_LIMIT)
  {
    struct history_struct temp_entry; // Temporary struct to hold data before locking

    temp_entry.pid = curproc->pid;
    safestrcpy(temp_entry.name, curproc->name, sizeof(temp_entry.name));
    temp_entry.totalMemory = memUsage;

    acquire(&history_lock);

    if (historyCount < MAX_LIMIT)
    {
      int index = historyCount++;        // Reserve an index
      history_array[index] = temp_entry; // Copy the prepared entry
    }

    release(&history_lock);
  }
  curproc->state = ZOMBIE;
  sched();
  // (Control should never return here.)
  panic("zombie exit");
}

//
// wait: Wait for a child process to exit and return its pid.
// Returns -1 if there are no children.
//
int wait(void)
{
  struct proc *p;
  int havekids, pid;
  struct proc *curproc = myproc();

  acquire(&ptable.lock);
  for (;;)
  {
    havekids = 0;
    for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    {
      if (p->parent != curproc)
        continue;
      havekids = 1;
      if (p->state == ZOMBIE)
      {
        pid = p->pid;
        kfree(p->kstack);
        p->kstack = 0;
        freevm(p->pgdir);
        p->pid = 0;
        p->parent = 0;
        p->name[0] = 0;
        p->killed = 0;
        p->state = UNUSED;
        release(&ptable.lock);
        return pid;
      }
    }
    if (!havekids || curproc->killed)
    {
      release(&ptable.lock);
      return -1;
    }
    sleep(curproc, &ptable.lock);
  }
}

//
// scheduler: The process scheduler.
// Each CPU calls scheduler() after setting itself up.
// Scheduler never returns; it loops, picking a process to run.
//
void scheduler(void)
{
  struct proc *p;
  struct cpu *c = mycpu();
  c->proc = 0;

  for (;;)
  {
    // Enable interrupts on this processor.
    sti();
    acquire(&ptable.lock);
    for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    {
      if (p->state != RUNNABLE)
        continue;
      c->proc = p;
      switchuvm(p);
      p->state = RUNNING;
      swtch(&(c->scheduler), p->context);
      switchkvm();
      c->proc = 0;
    }
    release(&ptable.lock);
  }
}

//
// sched: Enter scheduler. Must hold only ptable.lock.
// This saves and restores intena because intena is a property
// of this kernel thread.
//
void sched(void)
{
  int intena;
  struct proc *p = myproc();

  if (!holding(&ptable.lock))
    panic("sched ptable.lock");
  if (mycpu()->ncli != 1)
    panic("sched locks");
  if (p->state == RUNNING)
    panic("sched running");
  if (readeflags() & FL_IF)
    panic("sched interruptible");
  intena = mycpu()->intena;
  swtch(&p->context, mycpu()->scheduler);
  mycpu()->intena = intena;
}

//
// yield: Give up the CPU for one scheduling round.
//
void yield(void)
{
  acquire(&ptable.lock);
  myproc()->state = RUNNABLE;
  sched();
  release(&ptable.lock);
}

//
// forkret: A fork child's very first scheduling by scheduler() will swtch here.
// "Return" to user space.
//
void forkret(void)
{
  static int first = 1;
  release(&ptable.lock);
  if (first)
  {
    first = 0;
    iinit(ROOTDEV);
    initlog(ROOTDEV);
  }
  // Return to "caller", actually trapret.
}

//
// sleep: Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
//
void sleep(void *chan, struct spinlock *lk)
{
  struct proc *p = myproc();

  if (p == 0)
    panic("sleep");
  if (lk == 0)
    panic("sleep without lk");

  if (lk != &ptable.lock)
  {
    acquire(&ptable.lock);
    release(lk);
  }
  p->chan = chan;
  p->state = SLEEPING;
  sched();
  p->chan = 0;
  if (lk != &ptable.lock)
  {
    release(&ptable.lock);
    acquire(lk);
  }
}

//
// wakeup1: Wake up all processes sleeping on chan. ptable.lock must be held.
//
static void
wakeup1(void *chan)
{
  struct proc *p;
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->state == SLEEPING && p->chan == chan)
      p->state = RUNNABLE;
  }
}

//
// wakeup: Wake up all processes sleeping on chan.
//
void wakeup(void *chan)
{
  acquire(&ptable.lock);
  wakeup1(chan);
  release(&ptable.lock);
}

//
// kill: Kill the process with the given pid.
// The process will not exit until it returns to user space.
//
int kill(int pid)
{
  struct proc *p;
  acquire(&ptable.lock);
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->pid == pid)
    {
      p->killed = 1;
      if (p->state == SLEEPING)
        p->state = RUNNABLE;
      release(&ptable.lock);
      return 0;
    }
  }
  release(&ptable.lock);
  return -1;
}

//
// procdump: Print a process listing to console (for debugging).
// Runs when user types ^P on the console.
//
void procdump(void)
{
  static char *states[] = {
      [UNUSED] "unused",
      [EMBRYO] "embryo",
      [SLEEPING] "sleep ",
      [RUNNABLE] "runble",
      [RUNNING] "run   ",
      [ZOMBIE] "zombie"};
  int i;
  struct proc *p;
  char *state;
  uint pc[10];

  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    cprintf("%d %s %s", p->pid, state, p->name);
    if (p->state == SLEEPING)
    {
      getcallerpcs((uint *)p->context->ebp + 2, pc);
      for (i = 0; i < 10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
  }
}
int deep_wrapper_sys_chmod(void)
{
  char *path;
  int mode;
  struct inode *ip;

  // Retrieve arguments first
  int path_status = argstr(0, &path);
  int mode_status = argint(1, &mode);

  // Validate input
  if (path_status < 0 || mode_status < 0 || mode < 0 || mode > 7)
    return -1;

  // Begin file system operation
  begin_op();

  // Locate the inode
  ip = namei(path);
  if (!ip)
  {
    end_op();
    return -1;
  }

  // Lock inode and update permission
  ilock(ip);
  ip->permission = mode;
  // cprintf("Updated permissions to %d\n", mode);
  iupdate(ip);
  iunlockput(ip);

  // End file system operation
  end_op();

  return 0;
}