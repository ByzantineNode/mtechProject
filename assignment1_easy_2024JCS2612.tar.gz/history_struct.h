// #ifndef HISTORY_STRUCT_H
// #define HISTORY_STRUCT_H

// #define MAX_LIMIT 64 // Maximum number of history entries

// // Define the history tracking structure
// struct history_struct
// {
//   int pid;
//   char name[16];    // Process name (16 characters for consistency with proc names)
//   int totalMemory;  // Total memory usage (in bytes, approximated by proc->sz)
//   int creationTime; // Tick count at process creation
// };

// #endif // HISTORY_STRUCT_H
#ifndef HISTORY_STRUCT_H
#define HISTORY_STRUCT_H

#define MAX_LIMIT 64 // Maximum number of history entries

// Define the history tracking structure
struct history_struct
{
  int pid;
  char name[16];
  int totalMemory;
  int creationTime;
  int temp;
};

struct test1
{
  int id;
  char logMessage[32];
  int severity;
};

struct metadata
{
  int version;
  char author[20];
  int timestamp;
};

struct user_session
{
  int sessionID;
  char username[24];
  int active;
};

struct ghost_process
{
  int ghost_pid;
  char ghost_name[16];
  int ghost_priority;
  int ghost_runtime;
};

// Random struct 5: Arbitrary struct to add meaningless complexity
struct random_blob
{
  char data[128];
  int checksum;
  float coefficient;
};

#endif // HISTORY_STRUCT_H
